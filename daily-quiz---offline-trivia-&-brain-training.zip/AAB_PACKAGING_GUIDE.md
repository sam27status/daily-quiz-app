# Packaging Daily Quiz as an Android App Bundle (.AAB) for Google Play

This application is built with 100% local question storage, responsive mobile layouts, compliant Web App Manifest, and Service Worker caching, making it directly packageable into an Android App Bundle (**AAB**) for Google Play Store publication.

---

## Method 1: Google Bubblewrap CLI (Recommended by Google)

Google Bubblewrap uses Trusted Web Activity (TWA) to wrap the web app into a certified Android project that outputs a release `.aab` bundle with native performance and tiny file size (< 2MB).

### 1. Build the Web Application
```bash
npm run build
```

### 2. Install Bubblewrap CLI
```bash
npm install -g @bubblewrap/cli
```

### 3. Initialize Android Project
```bash
bubblewrap init --manifest=https://YOUR_DOMAIN.com/manifest.webmanifest
```
Bubblewrap will automatically read the icons (192x192, 512x512, maskable) and settings from the manifest.

### 4. Build Release Android App Bundle (.aab)
```bash
bubblewrap build
```
This generates `app-release-bundle.aab` in your project folder, ready to upload directly to the **Google Play Console**.

---

## Method 2: Capacitor with Android Studio

If you want native Gradle compilation, custom Android SDK plugins, or native signing via Android Studio:

### 1. Install Capacitor
```bash
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
```

### 2. Initialize Capacitor & Add Android
```bash
# Initialize project
npx cap init "Daily Quiz" "com.dailyquiz.offlineapp" --web-dir dist

# Build the web bundle
npm run build

# Add native Android platform
npx cap add android

# Sync web assets into Android project
npx cap sync
```

### 3. Open in Android Studio & Generate AAB
```bash
npx cap open android
```
Inside Android Studio:
1. Go to **Build > Generate Signed Bundle / APK...**
2. Choose **Android App Bundle (.aab)**
3. Select your Keystore (or create a new upload key)
4. Choose **release** destination
5. Click **Finish**. Android Studio generates `app-release.aab` ready for Google Play Console.
