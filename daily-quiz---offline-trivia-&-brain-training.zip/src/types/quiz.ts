export type QuizCategory = 'general_knowledge' | 'english' | 'science' | 'history';

export interface Question {
  id: string;
  category: QuizCategory;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface QuizSession {
  category: QuizCategory | 'mixed';
  categoryTitle: string;
  questions: Question[];
  currentIndex: number;
  selectedAnswers: (number | null)[];
  isAnswered: boolean;
  score: number;
  streak: number;
  maxStreak: number;
  startTime: number;
  endTime?: number;
}

export interface QuizResultRecord {
  id: string;
  timestamp: number;
  category: QuizCategory | 'mixed';
  score: number;
  totalQuestions: number;
  timeSpentSeconds: number;
}

export interface UserStats {
  totalQuizzesPlayed: number;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  bestScoreByCategory: Record<QuizCategory | 'mixed', number>;
  currentDailyStreak: number;
  lastPlayedDate: string; // YYYY-MM-DD
  history: QuizResultRecord[];
}

export interface AppSettings {
  soundEnabled: boolean;
  hapticEnabled: boolean;
  autoAdvanceSeconds: number; // 0 for manual
  darkMode: boolean;
}
