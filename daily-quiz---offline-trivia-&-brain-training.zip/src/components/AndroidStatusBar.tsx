import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

export const AndroidStatusBar: React.FC<{ isEmbeddedPhone?: boolean }> = ({ isEmbeddedPhone = false }) => {
  const [timeStr, setTimeStr] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setTimeStr(`${hours % 12 || 12}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`w-full flex items-center justify-between px-5 pt-2 pb-1 text-xs select-none ${isEmbeddedPhone ? 'text-slate-300' : 'text-slate-400'}`}>
      {/* Time */}
      <span className="font-semibold tracking-tight">{timeStr}</span>

      {/* Camera cutout spacer on phone mockup */}
      {isEmbeddedPhone && (
        <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-800 shadow-inner flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
        </div>
      )}

      {/* System Icons */}
      <div className="flex items-center gap-1.5">
        <Signal className="w-3.5 h-3.5" />
        <Wifi className="w-3.5 h-3.5" />
        <BatteryMedium className="w-4 h-4 text-emerald-400" />
      </div>
    </div>
  );
};
