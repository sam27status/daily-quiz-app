import React from 'react';
import { X, Check, AlertCircle, Lightbulb } from 'lucide-react';
import { Question } from '../types/quiz';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  questions: Question[];
  selectedAnswers: (number | null)[];
}

export const ReviewModal: React.FC<Props> = ({
  isOpen,
  onClose,
  questions,
  selectedAnswers,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 p-6 text-slate-100 shadow-2xl relative my-6 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
          <div>
            <h2 className="text-lg font-bold text-white">Quiz Review</h2>
            <p className="text-xs text-slate-400">All 10 Questions with Detailed Answers</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Question List */}
        <div className="overflow-y-auto pr-1 py-4 space-y-4 text-xs divide-y divide-slate-800/60">
          {questions.map((q, idx) => {
            const userPick = selectedAnswers[idx];
            const isCorrect = userPick === q.correctIndex;
            const letters = ['A', 'B', 'C', 'D'];

            return (
              <div key={q.id} className="pt-3 first:pt-0 space-y-2.5">
                {/* Question title & status badge */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-md bg-slate-800 text-slate-300 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <p className="text-sm font-semibold text-white leading-snug">
                      {q.question}
                    </p>
                  </div>
                  {isCorrect ? (
                    <span className="shrink-0 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold text-[10px] flex items-center gap-1">
                      <Check className="w-3 h-3" /> Correct
                    </span>
                  ) : (
                    <span className="shrink-0 px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-semibold text-[10px] flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> Incorrect
                    </span>
                  )}
                </div>

                {/* 4 Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-7">
                  {q.options.map((opt, oIdx) => {
                    const isRightAnswer = oIdx === q.correctIndex;
                    const isUserChoice = oIdx === userPick;

                    let bgClass = 'bg-slate-950/60 border-slate-800 text-slate-400';
                    if (isRightAnswer) {
                      bgClass = 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200 font-medium';
                    } else if (isUserChoice && !isCorrect) {
                      bgClass = 'bg-rose-500/15 border-rose-500/40 text-rose-200 line-through';
                    }

                    return (
                      <div
                        key={oIdx}
                        className={`flex items-center gap-2 p-2 rounded-xl border text-[11px] ${bgClass}`}
                      >
                        <span className="w-4 h-4 rounded-full bg-slate-800/80 flex items-center justify-center text-[9px] font-bold text-slate-300 shrink-0">
                          {letters[oIdx]}
                        </span>
                        <span className="truncate">{opt}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                <div className="ml-7 p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-200 text-[11px] flex items-start gap-2">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">{q.explanation}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 shrink-0 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition cursor-pointer"
          >
            Done Reviewing
          </button>
        </div>
      </div>
    </div>
  );
};
