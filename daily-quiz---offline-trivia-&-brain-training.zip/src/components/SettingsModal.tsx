import React from 'react';
import { X, Volume2, VolumeX, Vibrate, RotateCcw, Smartphone, ShieldCheck, Info } from 'lucide-react';
import { AppSettings, UserStats } from '../types/quiz';
import { soundManager } from '../utils/audio';
import { hapticsManager } from '../utils/haptics';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onResetStats: () => void;
  onOpenAABGuide: () => void;
}

export const SettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetStats,
  onOpenAABGuide,
}) => {
  if (!isOpen) return null;

  const toggleSound = () => {
    const next = !settings.soundEnabled;
    soundManager.enabled = next;
    onUpdateSettings({ ...settings, soundEnabled: next });
    if (next) soundManager.playTap();
  };

  const toggleHaptics = () => {
    const next = !settings.hapticEnabled;
    hapticsManager.enabled = next;
    onUpdateSettings({ ...settings, hapticEnabled: next });
    if (next) hapticsManager.tap();
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset all your quiz scores and stats?')) {
      onResetStats();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-6 text-slate-100 shadow-2xl relative animate-scale-up">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h2 className="text-lg font-bold text-white">App Settings</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Setting Items */}
        <div className="py-4 space-y-4 text-sm">
          {/* Sound Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </div>
              <div>
                <p className="font-semibold text-white">Sound Effects</p>
                <p className="text-xs text-slate-400">Offline chime and alert tones</p>
              </div>
            </div>
            <button
              onClick={toggleSound}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.soundEnabled ? 'bg-indigo-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Haptic Vibration */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400">
                <Vibrate className="w-4 h-4" />
              </div>
              <div>
                <p className="font-semibold text-white">Haptic Feedback</p>
                <p className="text-xs text-slate-400">Phone vibration on answers</p>
              </div>
            </div>
            <button
              onClick={toggleHaptics}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.hapticEnabled ? 'bg-indigo-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                  settings.hapticEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* AAB Packaging Guide Button */}
          <button
            onClick={() => {
              onClose();
              onOpenAABGuide();
            }}
            className="w-full flex items-center justify-between p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-left hover:bg-emerald-500/15 transition cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <p className="font-semibold text-emerald-300">Google Play AAB Guide</p>
                <p className="text-xs text-slate-400">Instructions for .aab bundle</p>
              </div>
            </div>
            <span className="text-xs font-semibold text-emerald-400">View &rarr;</span>
          </button>

          {/* Reset Stats */}
          <button
            onClick={handleReset}
            className="w-full flex items-center gap-3 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/15 transition text-left cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 flex items-center justify-center text-rose-400">
              <RotateCcw className="w-4 h-4" />
            </div>
            <div>
              <p className="font-semibold">Reset Statistics</p>
              <p className="text-xs text-slate-400">Clear high scores and play streak</p>
            </div>
          </button>
        </div>

        {/* Info */}
        <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-500 text-center flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Daily Quiz v1.0 • 100% Offline & Private</span>
        </div>
      </div>
    </div>
  );
};
