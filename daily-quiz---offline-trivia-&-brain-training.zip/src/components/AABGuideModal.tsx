import React from 'react';
import { X, Play, Package, Terminal, Smartphone, CheckCircle, ExternalLink } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const AABGuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 p-6 text-slate-100 shadow-2xl relative my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Google Play Packaging (.AAB)</h2>
              <p className="text-xs text-slate-400">Convert Daily Quiz into an Android App Bundle</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="mt-4 space-y-4 text-xs text-slate-300 leading-relaxed max-h-[65vh] overflow-y-auto pr-1">
          <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-200">
            <p className="font-semibold text-white mb-1">Ready for Google Play Store</p>
            Daily Quiz is built with an offline-first architecture, responsive mobile layouts, compliant Web App Manifest, and service worker. You can package it into a native Android App Bundle (<strong>.aab</strong>) in 2 easy ways:
          </div>

          {/* Option 1: Bubblewrap (Official Google TWA) */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">1</span>
              <span>Method A: Bubblewrap (Google’s Official TWA CLI)</span>
            </div>
            <p className="text-slate-400">
              Google’s recommended CLI generates a lightweight, 100% compliant Android project ready for Play Store signing:
            </p>
            <div className="bg-slate-900 rounded-xl p-3 font-mono text-[11px] text-emerald-400 overflow-x-auto space-y-1">
              <div># 1. Install Google Bubblewrap CLI</div>
              <div>npm install -g @bubblewrap/cli</div>
              <div className="pt-1"># 2. Build production assets</div>
              <div>npm run build</div>
              <div className="pt-1"># 3. Initialize Android project</div>
              <div>bubblewrap init --manifest=https://your-domain.com/manifest.webmanifest</div>
              <div className="pt-1"># 4. Generate signed release AAB</div>
              <div>bubblewrap build</div>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] font-medium pt-1">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Outputs: <code>app-release-bundle.aab</code></span>
            </div>
          </div>

          {/* Option 2: Capacitor */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">2</span>
              <span>Method B: Capacitor (Android Studio)</span>
            </div>
            <p className="text-slate-400">
              For full native SDK access, push notifications, and custom Java/Kotlin plugins:
            </p>
            <div className="bg-slate-900 rounded-xl p-3 font-mono text-[11px] text-indigo-300 overflow-x-auto space-y-1">
              <div># 1. Install Capacitor</div>
              <div>npm install @capacitor/core @capacitor/android</div>
              <div>npm install -D @capacitor/cli</div>
              <div className="pt-1"># 2. Initialize project</div>
              <div>npx cap init "Daily Quiz" "com.dailyquiz.app"</div>
              <div className="pt-1"># 3. Add Android platform & build</div>
              <div>npm run build && npx cap add android</div>
              <div>npx cap open android</div>
            </div>
            <p className="text-slate-400 pt-1">
              In Android Studio, select <strong>Build &gt; Generate Signed Bundle / APK &gt; Android App Bundle</strong>.
            </p>
          </div>

          {/* Offline & Google Play Compliance Checklist */}
          <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-1.5">
            <h4 className="font-semibold text-white text-xs">Included Play Store Compliances:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 text-[11px]">
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% Offline Local Database</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>192px & 512px High-Res Icons</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Android Maskable Icon Safe Zone</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Standalone Display Mode</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
