import React, { useState } from 'react';
import {
  ArrowLeft,
  Flame,
  CheckCircle2,
  XCircle,
  Lightbulb,
  ArrowRight,
  Trophy,
} from 'lucide-react';
import { Question, QuizCategory } from '../types/quiz';
import { soundManager } from '../utils/audio';
import { hapticsManager } from '../utils/haptics';

interface Props {
  category: QuizCategory | 'mixed';
  categoryTitle: string;
  questions: Question[];
  onFinishQuiz: (score: number, selectedAnswers: (number | null)[], timeSpentSeconds: number) => void;
  onExit: () => void;
}

export const QuizScreen: React.FC<Props> = ({
  category,
  categoryTitle,
  questions,
  onFinishQuiz,
  onExit,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(
    new Array(questions.length).fill(null)
  );
  const [isAnswered, setIsAnswered] = useState(false);
  const [currentScore, setCurrentScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [startTime] = useState<number>(Date.now());

  const currentQuestion = questions[currentIndex];
  const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);
  const optionLetters = ['A', 'B', 'C', 'D'];

  const handleSelectOption = (optionIndex: number) => {
    // If already answered this question, do not allow changes
    if (isAnswered) return;

    const isCorrect = optionIndex === currentQuestion.correctIndex;
    const newAnswers = [...selectedAnswers];
    newAnswers[currentIndex] = optionIndex;
    setSelectedAnswers(newAnswers);
    setIsAnswered(true);

    if (isCorrect) {
      setCurrentScore((prev) => prev + 1);
      setStreak((prev) => prev + 1);
      soundManager.playCorrect();
      hapticsManager.correct();
    } else {
      setStreak(0);
      soundManager.playIncorrect();
      hapticsManager.incorrect();
    }
  };

  const handleNext = () => {
    soundManager.playTap();
    hapticsManager.tap();

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setIsAnswered(false);
    } else {
      // Quiz complete!
      const timeSpent = Math.max(1, Math.round((Date.now() - startTime) / 1000));
      onFinishQuiz(currentScore, selectedAnswers, timeSpent);
    }
  };

  const handleExitConfirm = () => {
    if (window.confirm('Do you want to leave this quiz? Your current progress will be lost.')) {
      soundManager.playTap();
      onExit();
    }
  };

  return (
    <div className="flex-1 flex flex-col px-4 py-3 max-w-md mx-auto w-full select-none">
      {/* Top Bar */}
      <div className="flex items-center justify-between py-2 mb-2">
        <button
          onClick={handleExitConfirm}
          className="p-2 rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:text-white active:scale-95 transition cursor-pointer"
          title="Exit Quiz"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        {/* Category Badge */}
        <div className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-bold text-indigo-300">
          {categoryTitle}
        </div>

        {/* Streak Counter */}
        <div
          className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold transition-all ${
            streak > 1
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
              : 'bg-slate-900 border border-slate-800 text-slate-400'
          }`}
        >
          <Flame className={`w-3.5 h-3.5 ${streak > 1 ? 'text-amber-400 fill-amber-400' : ''}`} />
          <span>{streak}</span>
        </div>
      </div>

      {/* Progress & Question Counter */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-1.5 px-1">
          <span>
            Question <strong className="text-white">{currentIndex + 1}</strong> of {questions.length}
          </span>
          <span className="text-indigo-400 font-bold">{progressPercent}%</span>
        </div>

        {/* Progress Bar Container */}
        <div className="h-2 w-full rounded-full bg-slate-800/80 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl shadow-black/20 mb-4 flex-shrink-0">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            {currentQuestion.difficulty}
          </span>
          <span className="text-xs font-semibold text-slate-400">
            Score: <strong className="text-white">{currentScore}</strong>
          </span>
        </div>
        <h2 className="text-base sm:text-lg font-bold text-white leading-relaxed">
          {currentQuestion.question}
        </h2>
      </div>

      {/* 4 Answer Options */}
      <div className="flex-1 flex flex-col gap-2.5 justify-center mb-4">
        {currentQuestion.options.map((option, optIdx) => {
          const userPickedThis = selectedAnswers[currentIndex] === optIdx;
          const isRightOption = optIdx === currentQuestion.correctIndex;

          let cardStyle = 'bg-slate-900/80 border-slate-800 text-slate-200 hover:bg-slate-800/80 active:scale-[0.98]';
          let letterStyle = 'bg-slate-800 text-slate-300 border-slate-700';
          let icon = null;

          if (isAnswered) {
            if (isRightOption) {
              // Highlight the correct answer in emerald green
              cardStyle = 'bg-emerald-500/20 border-emerald-500/60 text-emerald-100 shadow-md shadow-emerald-950/40';
              letterStyle = 'bg-emerald-600 text-white border-emerald-500';
              icon = <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />;
            } else if (userPickedThis && !isRightOption) {
              // Highlight the chosen wrong answer in ruby red
              cardStyle = 'bg-rose-500/20 border-rose-500/60 text-rose-100 shadow-md shadow-rose-950/40';
              letterStyle = 'bg-rose-600 text-white border-rose-500';
              icon = <XCircle className="w-5 h-5 text-rose-400 shrink-0" />;
            } else {
              // Dim other non-selected options
              cardStyle = 'bg-slate-900/40 border-slate-800/50 text-slate-500 opacity-60';
              letterStyle = 'bg-slate-800/50 text-slate-600 border-transparent';
            }
          }

          return (
            <button
              key={optIdx}
              onClick={() => handleSelectOption(optIdx)}
              disabled={isAnswered}
              className={`w-full flex items-center justify-between p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer ${cardStyle}`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-8 h-8 rounded-xl border flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${letterStyle}`}
                >
                  {optionLetters[optIdx]}
                </span>
                <span className="text-sm font-semibold leading-snug">
                  {option}
                </span>
              </div>
              {icon}
            </button>
          );
        })}
      </div>

      {/* Immediate Educational Explanation Card (revealed upon answering) */}
      {isAnswered && (
        <div className="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-100 mb-4 animate-fade-in text-xs leading-relaxed flex items-start gap-2.5">
          <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-amber-300 block mb-0.5">
              {selectedAnswers[currentIndex] === currentQuestion.correctIndex
                ? 'Correct! Explanation:'
                : 'Not quite. Explanation:'}
            </span>
            <span>{currentQuestion.explanation}</span>
          </div>
        </div>
      )}

      {/* Bottom Action Button (Next Question / Finish Quiz) */}
      {isAnswered ? (
        <button
          onClick={handleNext}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 active:scale-[0.98] text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <span>{currentIndex + 1 === questions.length ? 'View Final Score' : 'Next Question'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      ) : (
        <div className="py-3 text-center text-xs text-slate-500 font-medium">
          Select an option above to check your answer
        </div>
      )}
    </div>
  );
};
