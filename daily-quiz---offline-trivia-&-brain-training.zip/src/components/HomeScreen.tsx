import React from 'react';
import {
  Globe,
  BookOpen,
  Atom,
  Landmark,
  Zap,
  Flame,
  Trophy,
  Settings as SettingsIcon,
  Sparkles,
  ChevronRight,
  Target,
  BarChart3,
  Award,
} from 'lucide-react';
import { CATEGORIES } from '../data/questions';
import { QuizCategory, UserStats } from '../types/quiz';
import { PWAInstallButton } from './PWAInstallButton';
import { soundManager } from '../utils/audio';
import { hapticsManager } from '../utils/haptics';

interface Props {
  stats: UserStats;
  onSelectCategory: (category: QuizCategory | 'mixed') => void;
  onOpenSettings: () => void;
}

export const HomeScreen: React.FC<Props> = ({
  stats,
  onSelectCategory,
  onOpenSettings,
}) => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Globe':
        return <Globe className="w-6 h-6" />;
      case 'BookOpen':
        return <BookOpen className="w-6 h-6" />;
      case 'Atom':
        return <Atom className="w-6 h-6" />;
      case 'Landmark':
        return <Landmark className="w-6 h-6" />;
      default:
        return <Globe className="w-6 h-6" />;
    }
  };

  const handleStart = (cat: QuizCategory | 'mixed') => {
    soundManager.playTap();
    hapticsManager.tap();
    onSelectCategory(cat);
  };

  const overallAccuracy =
    stats.totalQuestionsAnswered > 0
      ? Math.round((stats.totalCorrect / stats.totalQuestionsAnswered) * 100)
      : 0;

  return (
    <div className="flex-1 flex flex-col px-4 py-3 max-w-md mx-auto w-full select-none">
      {/* Top Bar */}
      <div className="flex items-center justify-between py-2 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-500 flex items-center justify-center text-white shadow-md shadow-indigo-600/30 font-extrabold text-base">
            Q
          </div>
          <div>
            <h1 className="text-base font-extrabold tracking-tight text-white leading-none">
              Daily Quiz
            </h1>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">
              10-Question Brain Workout
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Daily Streak Pill */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold">
            <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
            <span>{stats.currentDailyStreak}</span>
          </div>

          <PWAInstallButton />

          <button
            onClick={() => {
              soundManager.playTap();
              hapticsManager.tap();
              onOpenSettings();
            }}
            className="p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 active:scale-95 text-slate-300 hover:text-white border border-slate-700/60 transition cursor-pointer"
            title="Settings"
            aria-label="Settings"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Hero Card: Quick Mixed Challenge */}
      <div
        onClick={() => handleStart('mixed')}
        className="relative overflow-hidden rounded-3xl p-5 mb-5 bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 text-white shadow-xl shadow-indigo-900/30 border border-indigo-400/20 cursor-pointer active:scale-[0.98] transition-all group"
      >
        {/* Decorative background sparks */}
        <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />
        <div className="absolute right-3 top-3 opacity-20 group-hover:opacity-30 transition-opacity">
          <Sparkles className="w-16 h-16 text-yellow-300" />
        </div>

        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/15 backdrop-blur-md text-[11px] font-semibold tracking-wide uppercase text-indigo-100 mb-2.5">
            <Zap className="w-3 h-3 text-amber-300 fill-amber-300" />
            <span>All-Round Challenge</span>
          </div>

          <h2 className="text-xl font-extrabold tracking-tight text-white mb-1">
            Quick 10 Quiz
          </h2>
          <p className="text-xs text-indigo-100/90 leading-relaxed mb-4 max-w-[260px]">
            10 mixed multiple-choice questions across General Knowledge, English, Science, & History.
          </p>

          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-semibold text-indigo-200">
              {stats.bestScoreByCategory['mixed'] > 0
                ? `Best Score: ${stats.bestScoreByCategory['mixed']} / 10`
                : '100% Offline Ready'}
            </span>
            <div className="flex items-center gap-1 px-3.5 py-1.5 rounded-full bg-white text-indigo-900 font-bold text-xs shadow-md group-hover:translate-x-0.5 transition-transform">
              <span>Start Now</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </div>

      {/* Category Section Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Choose Category (10 Questions)
        </h3>
        <span className="text-[11px] text-slate-500 font-medium">4 Topics</span>
      </div>

      {/* Category Cards (2x2 Grid) */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        {CATEGORIES.map((cat) => {
          const bestScore = stats.bestScoreByCategory[cat.id] || 0;

          return (
            <div
              key={cat.id}
              onClick={() => handleStart(cat.id)}
              className="relative flex flex-col justify-between p-4 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 active:scale-[0.97] transition-all cursor-pointer shadow-lg shadow-black/20 group overflow-hidden"
            >
              {/* Subtle top ambient glow */}
              <div
                className={`absolute top-0 right-0 w-24 h-24 rounded-full ${cat.accentBg} blur-2xl pointer-events-none group-hover:scale-125 transition-transform`}
              />

              {/* Icon & Best Score Badge */}
              <div className="flex items-center justify-between mb-3 relative z-10">
                <div
                  className={`w-11 h-11 rounded-2xl bg-gradient-to-tr ${cat.gradient} flex items-center justify-center text-white shadow-md`}
                >
                  {getCategoryIcon(cat.icon)}
                </div>

                {bestScore > 0 ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-amber-400 flex items-center gap-1">
                    <Trophy className="w-2.5 h-2.5 text-amber-400" />
                    {bestScore}/10
                  </span>
                ) : (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-400">
                    10 Qs
                  </span>
                )}
              </div>

              {/* Text Information */}
              <div className="relative z-10">
                <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                  {cat.name}
                </h4>
                <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {cat.description}
                </p>
              </div>

              {/* Bottom tap prompt */}
              <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-800/60 text-[11px] text-slate-400 font-semibold group-hover:text-white transition-colors">
                <span>Play Quiz</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Mini Stats Banner */}
      <div className="mt-auto p-3.5 rounded-3xl bg-slate-900/60 border border-slate-800/80">
        <div className="flex items-center justify-around text-center divide-x divide-slate-800">
          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Quizzes</p>
            <p className="text-base font-extrabold text-white mt-0.5">
              {stats.totalQuizzesPlayed}
            </p>
          </div>
          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Answered</p>
            <p className="text-base font-extrabold text-white mt-0.5">
              {stats.totalQuestionsAnswered}
            </p>
          </div>
          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Accuracy</p>
            <p className="text-base font-extrabold text-emerald-400 mt-0.5">
              {overallAccuracy}%
            </p>
          </div>
          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Streak</p>
            <p className="text-base font-extrabold text-amber-400 mt-0.5">
              {stats.currentDailyStreak}d
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
