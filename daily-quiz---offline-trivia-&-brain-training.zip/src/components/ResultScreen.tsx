import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Trophy,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  Target,
  Sparkles,
  BookOpen,
  Home,
  Share2,
} from 'lucide-react';
import { Question, QuizCategory } from '../types/quiz';
import { ReviewModal } from './ReviewModal';
import { soundManager } from '../utils/audio';
import { hapticsManager } from '../utils/haptics';

interface Props {
  category: QuizCategory | 'mixed';
  categoryTitle: string;
  score: number;
  totalQuestions: number;
  timeSpentSeconds: number;
  questions: Question[];
  selectedAnswers: (number | null)[];
  onTryAgain: () => void;
  onGoHome: () => void;
}

export const ResultScreen: React.FC<Props> = ({
  category,
  categoryTitle,
  score,
  totalQuestions,
  timeSpentSeconds,
  questions,
  selectedAnswers,
  onTryAgain,
  onGoHome,
}) => {
  const [isReviewOpen, setIsReviewOpen] = useState(false);
  const percentage = Math.round((score / totalQuestions) * 100);

  useEffect(() => {
    soundManager.playVictory();
    hapticsManager.celebration();

    if (percentage >= 70) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#4F46E5', '#10B981', '#F59E0B', '#EC4899', '#38BDF8'],
        });
      } catch {
        // Confetti fallback
      }
    }
  }, [percentage]);

  const getPerformanceBadge = () => {
    if (score === 10) {
      return {
        title: 'Perfect Mastermind! 🏆',
        desc: 'Flawless 10 out of 10. Outstanding trivia knowledge!',
        color: 'text-amber-400',
        bg: 'bg-amber-500/10 border-amber-500/20',
      };
    }
    if (score >= 8) {
      return {
        title: 'Excellent Job! 🌟',
        desc: 'Impressive accuracy! You really know your facts.',
        color: 'text-emerald-400',
        bg: 'bg-emerald-500/10 border-emerald-500/20',
      };
    }
    if (score >= 6) {
      return {
        title: 'Great Effort! 👍',
        desc: 'Solid performance. Just a little more practice to perfection.',
        color: 'text-indigo-400',
        bg: 'bg-indigo-500/10 border-indigo-500/20',
      };
    }
    return {
      title: 'Keep Practicing! 💪',
      desc: 'Every quiz expands your mind. Try again and beat your score!',
      color: 'text-purple-400',
      bg: 'bg-purple-500/10 border-purple-500/20',
    };
  };

  const badge = getPerformanceBadge();
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return mins > 0 ? `${mins}m ${remainder}s` : `${remainder}s`;
  };

  const handleShare = () => {
    soundManager.playTap();
    hapticsManager.tap();
    const text = `I just scored ${score}/10 on Daily Quiz (${categoryTitle})! Can you beat my score? 🧠✨`;
    if (navigator.share) {
      navigator.share({ title: 'Daily Quiz Result', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('Score copied to clipboard!');
    }
  };

  return (
    <div className="flex-1 flex flex-col px-4 py-3 max-w-md mx-auto w-full select-none justify-between">
      {/* Top Title */}
      <div className="text-center pt-2 pb-1">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20">
          {categoryTitle} Quiz Complete
        </span>
      </div>

      {/* Score Hero Card */}
      <div className="flex flex-col items-center justify-center p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl shadow-black/30 text-center relative overflow-hidden my-3">
        {/* Glow behind */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full bg-indigo-600/15 blur-3xl pointer-events-none" />

        {/* Circular Score Badge */}
        <div className="relative mb-3 flex items-center justify-center">
          <svg className="w-36 h-36 transform -rotate-90">
            <circle
              cx="72"
              cy="72"
              r="60"
              stroke="currentColor"
              strokeWidth="10"
              className="text-slate-800"
              fill="transparent"
            />
            <circle
              cx="72"
              cy="72"
              r="60"
              stroke="currentColor"
              strokeWidth="10"
              strokeDasharray={2 * Math.PI * 60}
              strokeDashoffset={2 * Math.PI * 60 * (1 - percentage / 100)}
              strokeLinecap="round"
              className="text-indigo-500 transition-all duration-1000 ease-out"
              fill="transparent"
            />
          </svg>

          <div className="absolute flex flex-col items-center">
            <span className="text-3xl font-extrabold text-white tracking-tight">
              {score}
              <span className="text-base text-slate-400 font-semibold">/{totalQuestions}</span>
            </span>
            <span className="text-xs font-bold text-emerald-400 mt-0.5">
              {percentage}%
            </span>
          </div>
        </div>

        {/* Appraisal Badge */}
        <div className={`px-4 py-2 rounded-2xl border ${badge.bg} mb-1 max-w-[280px]`}>
          <h3 className={`text-base font-extrabold ${badge.color}`}>
            {badge.title}
          </h3>
          <p className="text-xs text-slate-300 mt-0.5 leading-snug">
            {badge.desc}
          </p>
        </div>
      </div>

      {/* Metrics Row (4 stat chips) */}
      <div className="grid grid-cols-3 gap-2.5 mb-4">
        <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
          <div className="flex items-center justify-center text-emerald-400 mb-1">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Correct</p>
          <p className="text-sm font-bold text-white mt-0.5">{score}</p>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
          <div className="flex items-center justify-center text-rose-400 mb-1">
            <XCircle className="w-4 h-4" />
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Incorrect</p>
          <p className="text-sm font-bold text-white mt-0.5">{totalQuestions - score}</p>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
          <div className="flex items-center justify-center text-indigo-400 mb-1">
            <Clock className="w-4 h-4" />
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Time Taken</p>
          <p className="text-sm font-bold text-white mt-0.5">{formatTime(timeSpentSeconds)}</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col gap-2.5 mt-auto">
        {/* Try Again (Primary Button) */}
        <button
          onClick={() => {
            soundManager.playTap();
            hapticsManager.tap();
            onTryAgain();
          }}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 active:scale-[0.98] text-white font-extrabold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Try Again</span>
        </button>

        {/* Review Answers & Share Row */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => {
              soundManager.playTap();
              hapticsManager.tap();
              setIsReviewOpen(true);
            }}
            className="w-full py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 active:scale-[0.98] text-white font-semibold text-xs border border-slate-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-300" />
            <span>Review Answers</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 active:scale-[0.98] text-white font-semibold text-xs border border-slate-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-indigo-300" />
            <span>Share Score</span>
          </button>
        </div>

        {/* Back to Home / Categories */}
        <button
          onClick={() => {
            soundManager.playTap();
            hapticsManager.tap();
            onGoHome();
          }}
          className="w-full py-2.5 text-slate-400 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
        >
          <Home className="w-3.5 h-3.5" />
          <span>Choose Another Category</span>
        </button>
      </div>

      {/* Review Answers Modal */}
      <ReviewModal
        isOpen={isReviewOpen}
        onClose={() => setIsReviewOpen(false)}
        questions={questions}
        selectedAnswers={selectedAnswers}
      />
    </div>
  );
};
