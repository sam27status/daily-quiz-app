/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HomeScreen } from './components/HomeScreen';
import { QuizScreen } from './components/QuizScreen';
import { ResultScreen } from './components/ResultScreen';
import { SettingsModal } from './components/SettingsModal';
import { AABGuideModal } from './components/AABGuideModal';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { OfflineIndicator } from './components/PWAInstallButton';
import { getQuizQuestions, CATEGORIES } from './data/questions';
import {
  QuizCategory,
  Question,
  UserStats,
  AppSettings,
} from './types/quiz';
import { soundManager } from './utils/audio';
import { hapticsManager } from './utils/haptics';
import { Smartphone, Monitor } from 'lucide-react';

const STATS_STORAGE_KEY = 'daily_quiz_stats_v1';
const SETTINGS_STORAGE_KEY = 'daily_quiz_settings_v1';

const defaultStats: UserStats = {
  totalQuizzesPlayed: 0,
  totalQuestionsAnswered: 0,
  totalCorrect: 0,
  bestScoreByCategory: {
    general_knowledge: 0,
    english: 0,
    science: 0,
    history: 0,
    mixed: 0,
  },
  currentDailyStreak: 1,
  lastPlayedDate: '',
  history: [],
};

const defaultSettings: AppSettings = {
  soundEnabled: true,
  hapticEnabled: true,
  autoAdvanceSeconds: 0,
  darkMode: true,
};

export default function App() {
  const [screen, setScreen] = useState<'home' | 'quiz' | 'result'>('home');
  const [currentCategory, setCurrentCategory] = useState<QuizCategory | 'mixed'>('mixed');
  const [currentQuestions, setCurrentQuestions] = useState<Question[]>([]);
  const [lastScore, setLastScore] = useState(0);
  const [lastSelectedAnswers, setLastSelectedAnswers] = useState<(number | null)[]>([]);
  const [lastTimeSpent, setLastTimeSpent] = useState(0);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAABGuideOpen, setIsAABGuideOpen] = useState(false);

  // Phone frame simulation toggle for desktop preview
  const [isPhoneFrameMode, setIsPhoneFrameMode] = useState(true);

  // Local storage state
  const [stats, setStats] = useState<UserStats>(() => {
    try {
      const saved = localStorage.getItem(STATS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Storage unavailable or disabled
    }
    return defaultStats;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        soundManager.enabled = parsed.soundEnabled ?? true;
        hapticsManager.enabled = parsed.hapticEnabled ?? true;
        return parsed;
      }
    } catch {
      // Storage unavailable
    }
    return defaultSettings;
  });

  // Save stats when changed
  useEffect(() => {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    } catch {
      // Storage full or quota exceeded
    }
  }, [stats]);

  // Save settings when changed
  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(newSettings));
    } catch {
      // Storage full
    }
  };

  const handleResetStats = () => {
    const fresh: UserStats = {
      ...defaultStats,
      lastPlayedDate: new Date().toISOString().slice(0, 10),
    };
    setStats(fresh);
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(fresh));
    } catch {}
    setIsSettingsOpen(false);
  };

  // Start a new 10-question quiz
  const handleStartCategory = (category: QuizCategory | 'mixed') => {
    const questions = getQuizQuestions(category);
    setCurrentCategory(category);
    setCurrentQuestions(questions);
    setScreen('quiz');
  };

  // Finish quiz handler
  const handleFinishQuiz = (
    score: number,
    selectedAnswers: (number | null)[],
    timeSpentSeconds: number
  ) => {
    setLastScore(score);
    setLastSelectedAnswers(selectedAnswers);
    setLastTimeSpent(timeSpentSeconds);

    // Update streak and persistent statistics
    const today = new Date().toISOString().slice(0, 10);
    setStats((prev) => {
      let streak = prev.currentDailyStreak;
      if (prev.lastPlayedDate) {
        const prevDate = new Date(prev.lastPlayedDate);
        const currentDate = new Date(today);
        const diffDays = Math.round(
          (currentDate.getTime() - prevDate.getTime()) / (1000 * 3600 * 24)
        );
        if (diffDays === 1) {
          streak += 1;
        } else if (diffDays > 1) {
          streak = 1;
        }
      } else {
        streak = 1;
      }

      const prevBest = prev.bestScoreByCategory[currentCategory] || 0;
      const updatedBest = Math.max(prevBest, score);

      return {
        ...prev,
        totalQuizzesPlayed: prev.totalQuizzesPlayed + 1,
        totalQuestionsAnswered: prev.totalQuestionsAnswered + currentQuestions.length,
        totalCorrect: prev.totalCorrect + score,
        bestScoreByCategory: {
          ...prev.bestScoreByCategory,
          [currentCategory]: updatedBest,
        },
        currentDailyStreak: streak,
        lastPlayedDate: today,
        history: [
          {
            id: String(Date.now()),
            timestamp: Date.now(),
            category: currentCategory,
            score,
            totalQuestions: currentQuestions.length,
            timeSpentSeconds,
          },
          ...prev.history.slice(0, 20),
        ],
      };
    });

    setScreen('result');
  };

  const getCategoryTitle = (cat: QuizCategory | 'mixed') => {
    if (cat === 'mixed') return 'Mixed Trivia';
    const found = CATEGORIES.find((c) => c.id === cat);
    return found ? found.name : 'Daily Quiz';
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-0 sm:p-4 select-none relative font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Desktop view switcher (hidden on mobile) */}
      <div className="hidden lg:flex fixed top-4 right-4 z-40 items-center gap-2 bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl shadow-xl backdrop-blur-md">
        <button
          onClick={() => setIsPhoneFrameMode(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            isPhoneFrameMode
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
          title="Simulate Android Handset Frame"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Phone Frame</span>
        </button>
        <button
          onClick={() => setIsPhoneFrameMode(false)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            !isPhoneFrameMode
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
          title="Adaptive Wide View"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Full Width</span>
        </button>
      </div>

      {/* Main Container: Adapts as an authentic Android device mockup on desktop, or edge-to-edge on mobile */}
      <div
        className={`w-full flex flex-col transition-all duration-300 ${
          isPhoneFrameMode
            ? 'max-w-[420px] min-h-[100dvh] sm:min-h-[820px] sm:max-h-[880px] bg-slate-950 sm:border-[10px] sm:border-slate-800/90 sm:rounded-[48px] sm:shadow-2xl sm:shadow-indigo-950/40 relative sm:overflow-hidden ring-1 ring-slate-700/40'
            : 'max-w-2xl min-h-[100dvh] sm:min-h-[780px] bg-slate-950 sm:border sm:border-slate-800 sm:rounded-3xl sm:shadow-xl sm:overflow-hidden'
        }`}
      >
        {/* Android Simulated Status Bar (visible in Phone Frame or on mobile) */}
        <AndroidStatusBar isEmbeddedPhone={isPhoneFrameMode} />

        {/* Dynamic Screen View */}
        <div className="flex-1 flex flex-col overflow-y-auto">
          {screen === 'home' && (
            <HomeScreen
              stats={stats}
              onSelectCategory={handleStartCategory}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />
          )}

          {screen === 'quiz' && (
            <QuizScreen
              category={currentCategory}
              categoryTitle={getCategoryTitle(currentCategory)}
              questions={currentQuestions}
              onFinishQuiz={handleFinishQuiz}
              onExit={() => setScreen('home')}
            />
          )}

          {screen === 'result' && (
            <ResultScreen
              category={currentCategory}
              categoryTitle={getCategoryTitle(currentCategory)}
              score={lastScore}
              totalQuestions={currentQuestions.length}
              timeSpentSeconds={lastTimeSpent}
              questions={currentQuestions}
              selectedAnswers={lastSelectedAnswers}
              onTryAgain={() => handleStartCategory(currentCategory)}
              onGoHome={() => setScreen('home')}
            />
          )}
        </div>

        {/* Android Navigation Bar Pill indicator at bottom */}
        {isPhoneFrameMode && (
          <div className="w-full flex items-center justify-center py-2 select-none pointer-events-none">
            <div className="w-32 h-1 rounded-full bg-slate-700/80" />
          </div>
        )}
      </div>

      {/* Global Offline Readiness Indicator */}
      <OfflineIndicator />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onResetStats={handleResetStats}
        onOpenAABGuide={() => setIsAABGuideOpen(true)}
      />

      {/* Google Play .AAB Packaging Guide Modal */}
      <AABGuideModal
        isOpen={isAABGuideOpen}
        onClose={() => setIsAABGuideOpen(false)}
      />
    </main>
  );
}
