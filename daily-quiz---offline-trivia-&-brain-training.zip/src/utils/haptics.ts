/**
 * Mobile Haptic feedback utility utilizing Navigator.vibrate.
 * Provides authentic Android tactile feel.
 */

class HapticsManager {
  public enabled: boolean = true;

  private vibrate(pattern: number | number[]) {
    if (!this.enabled || typeof window === 'undefined' || !('vibrate' in navigator)) {
      return;
    }
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore vibration error on unsupported platforms
    }
  }

  public tap() {
    this.vibrate(12);
  }

  public correct() {
    this.vibrate([20, 30, 40]);
  }

  public incorrect() {
    this.vibrate([60, 40, 60]);
  }

  public celebration() {
    this.vibrate([40, 60, 80, 60, 120]);
  }
}

export const hapticsManager = new HapticsManager();
